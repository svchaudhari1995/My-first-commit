import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable()
export class SwitchPreviewService {
flag : boolean = false;
  constructor() { }
isAuthenticated(){
  this.flag = !this.flag;
} 

private messageSource3 = new BehaviorSubject(false);
private messageSource4 = new BehaviorSubject('asa');
private messageSource5 = new BehaviorSubject('zx');
resourceload= this.messageSource3.asObservable();
urlimg= this.messageSource4.asObservable();
gdisease=this.messageSource5.asObservable();
changeMessage(resourceload:boolean) {

this.messageSource3.next(resourceload);
}

changeURL(urlimg:string) {

this.messageSource4.next(urlimg);
}

changedisease(gdisease:string)
{
  this.messageSource5.next(gdisease);
}
}   