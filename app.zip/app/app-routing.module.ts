import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DetectionComponent } from './detection/detection.component';
import { UploadComponent } from './detection/upload/upload.component';
import { MapComponent } from './map/map.component';
//import { AboutComponent } from 'src/app/about/about.component';
//import { ContactsComponent } from 'src/app/contacts/contacts.component';

const routes: Routes = [
  {
    path:'',
    component: DetectionComponent
  },
  {
    path:'detection',
    component: DetectionComponent
  },
  {
    path:'map',
    component: MapComponent
  },
  // {
  //   path: 'reports',
  //   component: ReportsComponent
  // }
  // {
  //   path: 'about',
  //   component: AboutComponent
  // },
  // {
  //   path: 'contacts',
  //   component: ContactsComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
