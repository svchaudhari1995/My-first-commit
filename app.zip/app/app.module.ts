import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import{HttpClientModule} from '@angular/common/http';
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
 import { SwitchPreviewService } from './switch-preview.service';
// import { CovalentFileModule } from '@covalent/core/file';
// import { TdFileService, IUploadOptions } from '@covalent/core/file';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import {UploadService} from "./upload.service";
import {HttpEventType,HttpResponse} from "@angular/common/http";
import {MatToolbarModule,MatIconModule,MatDatepickerModule,

    MatAutocompleteModule,
  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,

  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,

  MatTooltipModule,
  MatTreeModule,}   from '@angular/material';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MapComponent } from './map/map.component';
import { DetectionComponent } from './detection/detection.component';
import { PreviewComponent } from './detection/preview/preview.component';
import { UploadComponent } from './detection/upload/upload.component'

@NgModule({
  imports:      [ BrowserModule, FormsModule,HttpClientModule,MatToolbarModule,MatIconModule, MatDatepickerModule,

    BrowserAnimationsModule,
AppRoutingModule,

  MatBadgeModule,
  MatBottomSheetModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatDividerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  // MatTooltipModule,
  MatTreeModule,
  BrowserModule
],
  declarations: [ AppComponent, HelloComponent, SidebarComponent, MapComponent, DetectionComponent, PreviewComponent, UploadComponent],
    providers: [SwitchPreviewService ,UploadService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
