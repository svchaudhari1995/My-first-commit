import { Component, OnInit } from '@angular/core';
import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, OnDestroy } from '@angular/core';


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit, OnDestroy {
  mobileQuery: MediaQueryList;
  resourceload:any;
  private _mobileQueryListner: () => void;
  element: HTMLElement ;
  constructor( changeDetectorRef: ChangeDetectorRef, media: MediaMatcher) {
    this.mobileQuery = media.matchMedia('(max-width: 600px)');
    this._mobileQueryListner = () => changeDetectorRef.detectChanges();
    this.mobileQuery.addListener(this._mobileQueryListner);
   }

  ngOnInit() {
   
  }
  ngOnDestroy(): void {
    this.mobileQuery.removeListener(this._mobileQueryListner);

  }
  public toggleActive(event:any){
    event.preventDefault();
    var target = event.target || event.srcElement || event.currentTarget;
    if(this.element !== undefined){
      this.element.style.backgroundColor = "#061838";
    }
    target.style.backgroundColor = "#444E5F";
    this.element = target;
  }

}
