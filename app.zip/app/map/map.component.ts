import { Component, OnInit } from '@angular/core';
declare let L;
// declare let d3;
import * as d3 from 'd3';
@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log('test');
    d3.json('src/assets/data/geojson/dists11.geojson').then(function(districts){
      // console.log('test');
      d3.csv('src/assets/data/csv/dist_crop.csv').then(function(info){
        d3.json('src/assets/data/geojson/color.json').then(function(color){
        // console.log("test")
        var map = L.map('map',{scrollWheelZoom:false}).setView([23.40, 83.00], 6);
        var tile = L.tileLayer('http://{s}.tiles.wmflabs.org/bw-mapnik/{z}/{x}/{y}.png', {
          maxZoom: 18,
          minZoom:2,
          attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);
        var prop =  'major_crop'
        var getColor = d3.interpolateRgb("#fff7ec",'#7f0000');
        var getTitle = function(){
          return 	prop=='major_crop'? 'Major Crop' :
              prop=='major_disease'? 'Major Disease':
              'Not Defined'
        }
        var printval = function(str){
          // console.log(str);
          
          if(prop == 'major_crop')
          {
            for(var i=0;i<color['crops'].length;i++)
            {
              if(color['crops'][i]["crop"] == str)
              {
                console.log(color['crops'][i]['color']);
                return color['crops'][i]['color'];
              } 
            }
            // console.log(test_array)
          }
          if(prop == 'major_disease')
          {
            for(var i=0;i<color['diseases'].length;i++)
            {
              if(color['diseases'][i]["disease"] == str)
              {
                console.log(color['diseases'][i]['color']);
                return color['diseases'][i]['color'];
              }
            }
          }
          
        }
        var propColor = function(fepro){
          return  prop=='major_crop'?printval(fepro[prop]) :
              prop=='major_disease'?printval(fepro[prop]):
              getColor(0.5)
        }
        var style = function(feature) {
            return {
                fillColor: d3.rgb(propColor(feature['properties'])),//mnltr)/(mxltr-mnltr)),
                weight: 2,
                opacity: 1,
                color: 'white',
                dashArray: '3',
                fillOpacity: 0.7
            };
        }
        var infoTip = L.control();
        infoTip.onAdd = function (map) {
            this._div = L.DomUtil.create('div', 'info');
            this.update();
            return this._div;
        };
        infoTip.update = function (props) {
            this._div.innerHTML = '<h6>India '+getTitle()+'</h6>' +  (props ? prop == 'major_crop' ? 
                '<b>' + props.ST_NM + '</b><br />District : <b>' + props.DISTRICT + '</b><br />'+getTitle()+' : <b>' + props.major_crop + '</b>': prop == 'major_disease' ? '<b>' + props.ST_NM + '</b><br />District : <b>' + props.DISTRICT + '</b><br />'+getTitle()+' : <b>' + props.major_disease + '</b>':'Hover over a District' : 'Hover over a District');
        };
        infoTip.addTo(map);
  
        var legend = L.control({position: 'bottomright'});
        legend.onAdd = function (map) {
            var div = L.DomUtil.create('div', 'info legend-control')
            div.innerHTML +=
                '<h6>Select Metric</h6>' +
                    '<input type="button" style="clear: both" class="major_crop" value="Major Crop"></input><br>'+
                    '<input type="button" style="clear: both" class="major_disease" value="Major Disease"></input><br>'
            return div;
        };
        legend.addTo(map)
  
        var highlightFeature =function(e) {
            var layer = e.target;
  
            layer.setStyle({
                weight: 4,
                color: '#fff',
                dashArray: '',
                fillOpacity: 0.9
            });
  
            if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
                layer.bringToFront();
          }
          infoTip.update(layer.feature.properties);
        }
  
        var resetHighlight = function(e) {
            geolayer.resetStyle(e.target);
            infoTip.update();
        }
  
        var zoomToFeature = function(e) {
            map.fitBounds(e.target.getBounds());
        }
  
        var onEachFeature = function(feature, layer) {
            layer.on({
                mouseover: highlightFeature,
                mouseout: resetHighlight,
                click: zoomToFeature
            });
        }
  
        var getmajorcrop = function(distnm){
          var entry = info.filter(function(d){
            return d['dist'].trim().toLowerCase() == distnm.trim().toLowerCase()
          });
          return entry.length >0 ?(entry[0]['major_crop']) : 0
        }
        var getmajordisease = function(distnm){
          var entry = info.filter(function(d){
            return d['dist'].trim().toLowerCase() == distnm.trim().toLowerCase()
          });
          return entry.length >0 ?(entry[0]['major_disease']) : 0
        }
        var getcrop = function(distnm){
          var entry = info.filter(function(d){
            return d['dist'].trim().toLowerCase() == distnm.trim().toLowerCase()
          });
          return entry.length >0 ?(entry[0]['crops']) : 0
        }
        var getdisease = function(distnm){
          var entry = info.filter(function(d){
            return d['dist'].trim().toLowerCase() == distnm.trim().toLowerCase()
          });
          return entry.length >0 ?(entry[0]['disease']) : 0
        }
  
        for(var i=0; i<districts['features'].length ;i++){
          districts['features'][i]['properties']['major_crop'] = getmajorcrop(districts['features'][i]['properties']['DISTRICT'])
          districts['features'][i]['properties']['major_disease'] = getmajordisease(districts['features'][i]['properties']['DISTRICT'])
          districts['features'][i]['properties']['crops'] = getcrop(districts['features'][i]['properties']['DISTRICT'])
          districts['features'][i]['properties']['disease'] = getdisease(districts['features'][i]['properties']['DISTRICT'])
        }
  
        // var maxlitrate = d3.max(d3.values(districts['features']), function(d){return (d['properties']['litrate'])})
        // var minlitrate = d3.min(d3.values(districts['features']), function(d){return (d['properties']['litrate']==0)?maxlitrate:d['properties']['litrate']})
        // var maxsexratio = d3.max(d3.values(districts['features']), function(d){return (d['properties']['sexratio'])})
        // var minsexratio = d3.min(d3.values(districts['features']), function(d){return (d['properties']['sexratio']==0)?maxsexratio:d['properties']['sexratio']})
        // var maxarea = d3.max(d3.values(districts['features']), function(d){return (d['properties']['area'])})
        // var minarea = d3.min(d3.values(districts['features']), function(d){return (d['properties']['area']==0)?maxarea:d['properties']['area']})
        // var maxpopdensity = d3.max(d3.values(districts['features']), function(d){return (d['properties']['popdensity'])})
        // var minpopdensity = d3.min(d3.values(districts['features']), function(d){return (d['properties']['popdensity']==0)?maxpopdensity:d['properties']['popdensity']})
        // var maxworkpoprate = d3.max(d3.values(districts['features']), function(d){return (d['properties']['workpoprate'])})
        // var minworkpoprate = d3.min(d3.values(districts['features']), function(d){return (d['properties']['workpoprate']==0)?maxworkpoprate:d['properties']['workpoprate']})
        //adding The polygon from the districtjson
        var geolayer = L.geoJson(districts,{style: style, onEachFeature:onEachFeature}).addTo(map);
  
        d3.select('.legend-control').selectAll('input').on('click', function(){
          prop = d3.select(this).attr('class')
          geolayer.setStyle(style)
          infoTip.update()
        })
  
      })
    })
  })
  }

}