import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SwitchPreviewService } from './../../switch-preview.service';
// import { TdFileService, IUploadOptions } from '@covalent/core/file';
import {RequestOptions, Request, RequestMethod} from '@angular/http';
import { UploadService } from './../../upload.service';
import {HttpEventType,HttpResponse} from "@angular/common/http";
@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
})
export class UploadComponent implements OnInit {

   ngOnInit() {
  }

   constructor(private http:HttpClient,public myservice: SwitchPreviewService,public upload:UploadService){}
 
url:string="";
  selectedFile:File = null;

  public onFileChanged(event)
  {
   
    this.selectedFile = <File>event.target.files[0];
    // console.log((this.selectedFile.size)/1024/1024 )
     if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url =reader.result;
        console.log(event)
      }
    }
  }

 
  public onUpload() {
  // this.http is the injected HttpClient
  const uploadData = new FormData();
  uploadData.append('file', this.selectedFile, this.selectedFile.name);
  console.log("hi")
  this.http.post('http://34.220.242.188:8080/',uploadData)
    .subscribe(res =>{console.log(res)
      console.log(res['disease'])  
    this.myservice.changedisease(res['disease']);
    this.myservice.isAuthenticated();
this.myservice.changeURL(this.url) 
      }
  
  
  );

//  let options: IUploadOptions = {
//       url: 'http://34.220.242.188:8080/',
//       method: 'post',
//       file: this.selectedFile
//     };
//     this.fileUploadService.upload(options).subscribe((response) => {
//         console.log(response)
//     });

// this.test()
  





}



test()
{
 
 this.upload.uploadFile("https://34.220.242.188:8080/uploadImage", this.selectedFile)
      .subscribe(
        event => {
          if (event.type == HttpEventType.UploadProgress) {
            const percentDone = Math.round(100 * event.loaded / event.total);
            console.log(`File is ${percentDone}% loaded.`);
          } else if (event instanceof HttpResponse) {
            console.log('File is completely loaded!');
          }
        },
        (err) => {
          console.log("Upload Error:", err);
        }, () => {
          console.log("Upload done");
        }
      )
      
}
}