import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { SwitchPreviewService } from './../switch-preview.service';
@Component({
  selector: 'app-detection',
  templateUrl: './detection.component.html',
  styleUrls: ['./detection.component.css']
})
export class DetectionComponent implements OnInit {


  ngOnInit() {
  }

   constructor(public myservice: SwitchPreviewService) {
  }
}