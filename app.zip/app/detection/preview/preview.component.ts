import { Component, OnInit } from '@angular/core';
import { SwitchPreviewService } from './../../switch-preview.service';
@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.css']
})
export class PreviewComponent implements OnInit {
  url:String;
  disease:string="";
  crop:string="";
  remedies:any={"scab":"If disease levels were high the previous season, liquid copper fungicides can be sprayed to impede the fungal growth on the tree during the winter season. Sulfur sprays are only partially effective against apple scab. However, solutions containing sulfur and pyrethrins are available for organic control of the disease during the growing season. Always consider an integrated approach with preventive measures together with biological treatments if available. Protectant fungicides such as dodine, captan or dinathion can be sprayed around bud break to avoid the disease. Once scab has been detected, fungicides based on difenoconazole, myclobutanil or sulphur can be used to control the development of the fungus. Ensure scab fungicides from different chemical groups are used to avoid the development of resistance.",
"tomato late blight":"At this point, there is no biological control of known efficacy against late blight. To avoid spreading, remove and destroy plants around the infected spot immediately and do not compost infected plant material.Always consider an integrated approach with preventive measures together with biological treatments if available. Use fungicide sprays based on mandipropamid, chlorothalonil, fluazinam, mancozeb to combat late blight. Fungicides are generally needed only if the disease appears during a time of year when rain is likely or overhead irrigation is practiced"
,"potato early blight":"Small farmers may use algal limestone, a mixture of fat-free milk and water (1:1) or rock flour to treat infected plants. A solution of 3 teaspoon of bicarbonate of soda + fish emulsion in 4 liters of water also help. Application of products based on Bacillus subtilis or copper-based fungicides registered as organic also work.Always consider an integrated approach with preventive measures and biological treatments if available. There are numerous fungicides on the market for controlling early blight. Fungicides based on or combinations of azoxystrobin, pyraclostrobin, difenoconazole, boscalid, chlorothalonil, fenamidone, maneb, mancozeb, pyraclostrobin, trifloxystrobin and ziram. Rotation of different chemical compounds is recommended. Apply treatments in a timely manner, taking into account weather conditions."}
  remedy:string;
  ngOnInit() {
    

    this.myservice.urlimg.subscribe(message  =>  this.url  =  message)
    this.myservice.gdisease.subscribe(message  =>  this. disease =  message)
    console.log("initst")
   console.log(this.disease) 
   let x = this.disease.split(",")
   this.disease=x[1].split(":")[0]
   this.crop=x[0]
  this.remedy=this.remedies[this.disease]

   console.log("ngonit")
  }
 constructor(public myservice: SwitchPreviewService) {
  }
}